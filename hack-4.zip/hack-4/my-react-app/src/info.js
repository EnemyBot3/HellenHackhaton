import React, { useEffect, useState, useRef, useLayoutEffect } from 'react';
import styled from 'styled-components';
import Slider from './Slider';
import { ReactFitty } from "react-fitty";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPause, faPlay } from '@fortawesome/free-solid-svg-icons';

const Overlay = styled.div`
  position: absolute;
  top: 0%;
  left: 0%;
  width: 100vw;
  height: 100vh;
`;

const Container = styled.div`
    backdrop-filter: blur(3px);
    background-color: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 10px;
    box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.25);

    position: relative;
    top: 53%;
    left: 50%;
    transform: translate(-50%, -50%);

    width: 60%;
    apect-ratio: 16/4;
    // height: 70%;
    overflow-y: hidden;

    display: flex;
    justify-content: space-between;
    align-items: start;
    padding: 20px;

    @media (max-width: 850px) {
        flex-direction: column;
        align-items: center;
        text-align: center;
        width: 70%;
        height: 70%;
        overflow-y: scroll;
    }
`;

const TextSection = styled.div`
  flex: 1;
  align-self: center;
  color: white;
  width: 100%;
  height: 280px;
  overflow-y: scroll;
  overflow-x: hidden;
  position: relative;

  @media (max-width: 850px) {
    padding-left: 0px;
    overflow-y: visible;
    overflow-x: visible;
    width: 100%;
  }
`;

const Image = styled.img`
  border-radius: 10px;
  width: 35%;
  height: auto;
  align-self: center;
  margin-right: 3%;

  @media (max-width: 850px) {
    width: 80%;
    margin-top: 20px;
    margin-right: 0%;
  }
`;

const Controls = styled.div`
  position: absolute;
  width: 100px;
  height: 100px;
  bottom: 0px;

  display: flex;
  align-items: center;
  justify-content: center;

  @media (max-width: 850px) {
    top: 160px;
    bottom: 0px;
  }
`;

const PlayPause = styled(FontAwesomeIcon)`
    font-size: 40px;
    cursor: pointer;
    color: white;
`;

const Header = styled.h1`
  color: white;
  text-align: left;
  margin-bottom: 0px;
  margin-top: 0px;

  @media (max-width: 850px) {
    text-align: center;
    margin-top: 5%;
    font-size: 30px;
  }
`;


const InfoContainer = styled.div`
    display: flex;
    justify-content: space-between;
    align-items: start;
    padding-bottom: 30px;
    paddinig-left: 10px;
    flex-direction: column;
    margin-left: 20px;

    @media (max-width: 850px) {
        text-align: start;
        width: 80%;
        margin: auto;
    }
`;

const InfoItem = styled.div`
    display: flex;
    justify-content: space-between;
    align-items: start;
    flex-direction: column;
    width: 100%;

`;

const InfoLabel = styled.label`
    padding: 3px;
`;

const Headline = styled.label`
    font-weight: 900;
    font-size: x-large;
    font-style: italic;
`;

const Title = styled.p`
    position: absolute;
    transform: translateY(-203%);
    font-weight: 600;
    white-space: nowrap;
`;

function Info() {
    const [name, setName] = useState("");
    const [date, setDate] = useState("19580421");
    const [city, setCity] = useState(null);
    const [DoB, setDoB] = useState(null);
    const [DoD, setDoD] = useState(null);
    const [gender, setGender] = useState(null);
    const [image, setImage] = useState(null);
    const [headline, setHeadline] = useState("");

    const glassRef = useRef(null);
    const [glassPosition, setGlassPosition] = useState('32px');
    const imageRef = useRef(null);
    const [imagePosSize, setImagePosSize] = useState('32px');

    const [DATES, SETDATES] = useState([]);
    const [CONCERTS, SETCONCERTS] = useState([]);

    const [playing, setPlaying] = useState(false);
    
    useEffect(() => { uindowSize(); }, [])

    function uindowSize() {
        function updateSize() {
            if (glassRef?.current) {
                const top = parseInt(getComputedStyle(glassRef.current).top.split('p')[0]);
                const height = parseInt(getComputedStyle(glassRef.current).height.split('p')[0]);

                const left = parseInt(getComputedStyle(glassRef.current).left.split('p')[0]);
                const width = parseInt(getComputedStyle(glassRef.current).width.split('p')[0]);

                setGlassPosition({top: (top - (height / 2)) + "px", left: (left - (width / 2)) + "px"});
            }
            if (imageRef?.current) {
                const top = parseInt(getComputedStyle(imageRef.current).top.split('p')[0]);
                const height = parseInt(getComputedStyle(imageRef.current).height.split('p')[0]);

                const left = parseInt(getComputedStyle(imageRef.current).left.split('p')[0]);
                const width = parseInt(getComputedStyle(imageRef.current).width.split('p')[0]);

                setImagePosSize({top: (top - (width /19 * 4)) + "px", left: (left - (width / 2)) + "px", width: width + "px", height: height + "px"});
                console.log({top: (top - (width /19 * 4)) + "px", left: (left - (width / 2)) + "px", width: width + "px", height: height + "px"})
            }
        }
        updateSize();
        window.addEventListener('resize', updateSize);
        window.addEventListener('load', updateSize);
    }

    useEffect(() => {
      async function getEventsByDate(date) {
        let url = `https://www.vizgr.org/historical-events/search.php?format=json&limit=10&begin_date=${date}&end_date=${date}`;

        try {
          const rawResponse = await fetch(url);
          const content = await rawResponse.json();
          console.log("Event Description:", content);
          setHeadline(content.result.event.description);
        } catch (error) {
          console.error("Error fetching events:", error);
        }
      }

      getEventsByDate(date);
    }, [date]);

    // useEffect(() => {
    //     // fetch('http://localhost:4000/concerts?date=1859-02-02')
    //     //   .then(response => response.json())
    //     //   .then(data => {
    //     //     console.log(data); // Use setState here to update your component state
    //     //     SETCONCERTS(data)
    //     //   })
    //     //   .catch(error => console.error('Error fetching data:', error));

    //     fetch('http://localhost:4000/dates')
    //     .then(response => response.json())
    //     .then(data => {
    //     console.log(data); // Use setState here to update your component state
    //     SETDATES(data);
    //     })
    //     .catch(error => console.error('Error fetching data:', error));
    // }, []);

    useEffect(() => {
        const getEventsByDate = async (date) => {
          const url = `https://www.vizgr.org/historical-events/search.php?format=json&limit=10&begin_date=${date}&end_date=${date}`;
          try {
            const response = await fetch(url);
            const data = await response.json();
            if (data && data.result && data.result.event) {
              setHeadline(data.result.event.description);
            } else {
              console.error("No events found or malformed data received.");
            }
          } catch (error) {
            console.error("Error fetching events:", error);
          }
        };
      
        getEventsByDate(date);
    }, [date]);
      
    
    useEffect(() => {
        const fetchData = async () => {
          try {
            const datesResponse = await fetch('http://localhost:4000/dates');
            const dates = await datesResponse.json();
            SETDATES(dates);
          } catch (error) {
            console.error('Error fetching dates:', error);
          }
        };
      
        fetchData();
      }, []);
      
    //   const onDateMoved = async (newVal) => {
    //     try {
    //       const response = await fetch(`http://localhost:4000/concerts?date=${newVal}`);
    //       const concerts = await response.json();
    //       if (concerts.length > 0) {
    //         update(concerts[0].name);
    //         SETCONCERTS(concerts);
    //       } else {
    //         console.log('No concerts found for this date.');
    //       }
    //     } catch (error) {
    //       console.error('Error fetching concerts:', error);
    //     }
    //   };
      
    
    const update = async (name) => {
        const p = name;
        const Nname = name?.split(" ")[1] + " " + name?.split(',')[0]
        name = Nname ? Nname : p;
        const endpointUrl = 'https://query.wikidata.org/sparql';
        const sparqlQuery = `SELECT DISTINCT ?item ?itemLabel ?birthLocation  ?birthLocationLabel ?dateofbirth ?dateofdeath  ?genderLabel ?imageLabel WHERE {
            ?item (wdt:P31|wdt:P101|wdt:P106|wdt:P18)/wdt:P279* wd:Q482980 ;
                  rdfs:label "${name}"@en ;
                  wdt:P19 ?birthLocation;
                  wdt:P569 ?dateofbirth;
                  wdt:P21 ?gender;
                  wdt:P570 ?dateofdeath;
                  OPTIONAL { ?item wdt:P18 ?image }
            SERVICE wikibase:label { bd:serviceParam wikibase:language "en". }
        }
        `;
        try {
          const response = await fetch(endpointUrl + '?query=' + encodeURIComponent(sparqlQuery), {
            headers: { 'Accept': 'application/sparql-results+json' }
          });
          const data = await response.json();
          if (data.results.bindings.length > 0) {
            const result = data.results.bindings[0];
            setCity(result.birthLocationLabel?.value);
            setDoB(result.dateofbirth?.value.split('T')[0]);
            setDoD(result.dateofdeath?.value.split('T')[0]);
            setGender(result.genderLabel?.value);
            setImage(result.imageLabel?.value);
            setName(name);
          } else {
            console.log('No data found for:', name);
          }
        } catch (error) {
          console.error('Error querying Wikidata:', error);
        }
      };
      
    const onDateMoved = async(newVal) => {

        fetch(`http://localhost:4000/concerts?date=${newVal}`)
          .then(response => response.json())
          .then(data => {
            console.log(data); // Use setState here to update your component state
            
            update(data[0]?.name);
            
            
            SETCONCERTS(data)
            console.log(data);
          })
        .catch(error => console.error('Error fetching data:', error));


        


        console.log(newVal);
    }


  return (
    <>
    {CONCERTS.length > 0 ? <>
        <Title style={{top: glassPosition.top, left: glassPosition.left}}> 10th Concert of the 1st Season </Title>

      <Overlay>
        <Container ref={glassRef}>
            <Image ref={imageRef} src={image} alt="Sample" />
            <Controls style={{
                width: imagePosSize.width, 
                height: '100px', 
                top: imagePosSize.top, 
                left: imagePosSize.left
            }}> 
               {playing ? <PlayPause icon={faPause} onClick={() => setPlaying(false)}/> : <PlayPause icon={faPlay} onClick={() => setPlaying(true)}/>}
            
            </Controls>    

            <TextSection>
                <ReactFitty maxSize={30} wrapText={true} > <Header>{name}</Header> </ReactFitty>

                <InfoContainer>
                    <ReactFitty maxSize={20} minSize={10} wrapText> <InfoLabel > Date of Birth:  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {DoB}    </InfoLabel> </ReactFitty>
                    <ReactFitty maxSize={20} minSize={10} wrapText> <InfoLabel > Place of Birth: &nbsp;&nbsp;&nbsp;&nbsp; {city}   </InfoLabel> </ReactFitty>
                    <ReactFitty maxSize={20} minSize={10} wrapText> <InfoLabel > Gender:         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {gender} </InfoLabel> </ReactFitty>
                    <ReactFitty maxSize={20} minSize={10} wrapText> <InfoLabel > Date of Death:  &nbsp;&nbsp;&nbsp; {DoD}    </InfoLabel> </ReactFitty>
                </InfoContainer>


                <Headline style={{color: 'black', display: 'inline-block', paddingRight: '10px'}}> Today's Headline: </Headline>
                <Headline>{headline}</Headline>

                <ReactFitty maxSize={15} minSize={10} wrapText> <Header style={{marginTop: '30px'}}> Today's events: </Header> </ReactFitty>
                <InfoContainer>
                        <ReactFitty maxSize={20} minSize={3} wrapText> <InfoLabel > Work:     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 29 Jan - 1 Feb  </InfoLabel> </ReactFitty>
                        <ReactFitty maxSize={20} minSize={3} wrapText> <InfoLabel > Spans:    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 29 Jan - 1 Feb  </InfoLabel> </ReactFitty>
                        <ReactFitty maxSize={20} minSize={3} wrapText> <InfoLabel > Venue:    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Hallen   </InfoLabel> </ReactFitty>
                        <ReactFitty maxSize={20} minSize={3} wrapText> <InfoLabel > Time:     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 15:00   </InfoLabel> </ReactFitty>
                        <ReactFitty maxSize={20} minSize={3} wrapText> <InfoLabel > Orchestra:&nbsp;&nbsp;&nbsp;&nbsp; Name </InfoLabel> </ReactFitty>
                </InfoContainer>

            </TextSection>

        </Container>

      </Overlay>

      <Slider onDateMoved={onDateMoved}/> </>:<Slider onDateMoved={onDateMoved}/>}

    </>
  );
}

export default Info;
