import React, { useEffect, useState } from 'react';
import styled, { keyframes, css } from 'styled-components';

import Background from './background';
import Info from './info';

function App() {

  return (
    <>
      <Background />
      <Info />
    </>

  );
}

export default App;