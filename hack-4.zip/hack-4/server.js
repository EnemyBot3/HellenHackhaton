const express = require('express');
const mysql = require('mysql2');  // using mysql2 for better compatibility
const cors = require('cors');
const app = express();
const port = 4000;
app.use(cors());

// Configure MySQL connection
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'halley'
});

// Connect to the database
connection.connect(err => {
  if (err) {
    console.error('error connecting: ' + err.stack);
    return;
  }
  console.log('connected as id ' + connection.threadId);
});

// Middleware to parse JSON bodies
app.use(express.json());

// Define a route to get all composers
app.get('/composers', (req, res) => {
  connection.query('SELECT * FROM halle_composers', (err, results) => {
    if (err) {
      return res.status(500).json({ error: 'Error retrieving data' });
    }
    res.json(results);
  });
});


app.get('/concerts', (req, res) => {
    const { date } = req.query;
    console.log(req.query); // Now correctly logging the query parameters
    if (!date) {
        return res.status(400).json({ error: 'No date provided' });
    }
    const query = `SELECT * FROM halle_concerts AS C INNER JOIN halle_performances AS P on C.parent = P.id INNER JOIN halle_works AS W on P.work = W.id inner JOIN halle_composers AS COM on P.composer = COM.id WHERE C.date_start LIKE ? ORDER BY C.date_start`;
    
    connection.query(query, [`${date}%`], (err, results) => { // Safe parameterized query
      if (err) {
        console.error('SQL error:', err);
        return res.status(500).json({ error: 'Error retrieving data' });
      }
      res.json(results);
    });
});

// Define the API endpoint to get original dates
app.get('/dates', (req, res) => {
    const sqlQuery = `
      SELECT C.original_date 
      FROM halle_concerts AS C
      INNER JOIN halle_performances AS P ON C.parent = P.id
      INNER JOIN halle_works AS W ON P.work = W.id
      INNER JOIN halle_composers AS COM ON P.composer = COM.id
      ORDER BY C.date_start
    `;
  
    connection.query(sqlQuery, (err, results) => {
      if (err) {
        console.error('Failed to execute query:', err);
        return res.status(500).json({ error: 'Error retrieving concert dates' });
      }
      res.json(results);
    });
  });


// Define a route to get a single composer by ID
app.get('/composers/:id', (req, res) => {
  const { id } = req.params;
  connection.query('SELECT * FROM halle_composers WHERE id = ?', [id], (err, results) => {
    if (err) {
      return res.status(500).json({ error: 'Error retrieving data' });
    }
    if (results.length > 0) {
      res.json(results[0]);
    } else {
      res.status(404).json({ error: 'Composer not found' });
    }
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
