import React, { useEffect, useState, useRef, useLayoutEffect } from 'react';
import styled from 'styled-components';
import Slider from './Slider';
import { ReactFitty } from "react-fitty";

const Overlay = styled.div`
  position: absolute;
  top: 0%;
  left: 0%;
  width: 100vw;
  height: 100vh;
`;

const Container = styled.div`
    backdrop-filter: blur(3px);
    background-color: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 10px;
    box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.25);

    position: relative;
    top: 53%;
    left: 50%;
    transform: translate(-50%, -50%);

    width: 60%;
    apect-ratio: 16/4;
    // height: 70%;
    overflow-y: hidden;

    display: flex;
    justify-content: space-between;
    align-items: start;
    padding: 20px;

    @media (max-width: 850px) {
        flex-direction: column;
        align-items: center;
        text-align: center;
        width: 70%;
        height: 70%;
        overflow-y: scroll;
    }
`;

const TextSection = styled.div`
  flex: 1;
  align-self: center;
  color: white;
  width: 100%;
  height: 280px;
  overflow-y: scroll;
  overflow-x: hidden;
  position: relative;

  @media (max-width: 850px) {
    padding-left: 0px;
    overflow-y: visible;
    overflow-x: visible;
    width: 100%;
  }
`;

const Image = styled.img`
  border-radius: 10px;
  width: 35%;
  height: auto;
  align-self: center;
  margin-right: 3%;

  @media (max-width: 850px) {
    width: 80%;
    margin-top: 20px;
    margin-right: 0%;
  }
`;

const Controls = styled.div`
  position: absolute;
  width: 100px;
  height: 100px;
  top: 100px;
  background-color: red;
`;

const Header = styled.h1`
  color: white;
  text-align: left;
  margin-bottom: 0px;
  margin-top: 0px;

  @media (max-width: 850px) {
    text-align: center;
    margin-top: 5%;
    font-size: 30px;
  }
`;


const InfoContainer = styled.div`
    display: flex;
    justify-content: space-between;
    align-items: start;
    padding-bottom: 30px;
    paddinig-left: 10px;
    flex-direction: column;
    margin-left: 20px;

    @media (max-width: 850px) {
        text-align: start;
        width: 80%;
        margin: auto;
    }
`;

const InfoItem = styled.div`
    display: flex;
    justify-content: space-between;
    align-items: start;
    flex-direction: column;
    width: 100%;

`;

const InfoLabel = styled.label`
    padding: 3px;
`;

const Headline = styled.label`
    font-weight: 900;
    font-size: x-large;
    font-style: italic;
`;

const Title = styled.p`
    position: absolute;
    transform: translateY(-203%);
    font-weight: 600;
    white-space: nowrap;
`;

function Info() {
    const [date, setDate] = useState("19580421");
    const [city, setCity] = useState(null);
    const [DoB, setDoB] = useState(null);
    const [DoD, setDoD] = useState(null);
    const [gender, setGender] = useState(null);
    const [image, setImage] = useState(null);
    const [headline, setHeadline] = useState("");

    const headerRef = useRef(null);
    const [headerSize, setHeaderSize] = useState('32px');
    const glassRef = useRef(null);
    const [glassPosition, setGlassPosition] = useState('32px');
    const imageRef = useRef(null);
    const [imagePosSize, setImagePosSize] = useState('32px');
    useEffect(() => {
        uindowSize();
    }, [headerRef, headerRef?.current])

    useEffect(() => { uindowSize(); }, [])

    function uindowSize() {
        function updateSize() {
            if (headerRef?.current) { setHeaderSize(getComputedStyle(headerRef.current).fontSize); }
            if (glassRef?.current) {
                const top = parseInt(getComputedStyle(glassRef.current).top.split('p')[0]);
                const height = parseInt(getComputedStyle(glassRef.current).height.split('p')[0]);

                const left = parseInt(getComputedStyle(glassRef.current).left.split('p')[0]);
                const width = parseInt(getComputedStyle(glassRef.current).width.split('p')[0]);

                setGlassPosition({top: (top - (height / 2)) + "px", left: (left - (width / 2)) + "px"});
            }
            if (imageRef?.current) {
                const top = parseInt(getComputedStyle(imageRef.current).top.split('p')[0]);
                const height = parseInt(getComputedStyle(imageRef.current).height.split('p')[0]);

                const left = parseInt(getComputedStyle(imageRef.current).left.split('p')[0]);
                const width = parseInt(getComputedStyle(imageRef.current).width.split('p')[0]);

                setImagePosSize({top: (top - (width /19 * 4)) + "px", left: (left - (width / 2)) + "px", width: width + "px", height: height + "px"});
                console.log({top: (top - (width /19 * 4)) + "px", left: (left - (width / 2)) + "px", width: width + "px", height: height + "px"})
            }
        }
        updateSize();
        window.addEventListener('resize', updateSize);
        window.addEventListener('load', updateSize);
    }

    useEffect(() => {
      async function getEventsByDate(date) {
        let url = `https://www.vizgr.org/historical-events/search.php?format=json&limit=10&begin_date=${date}&end_date=${date}`;

        try {
          const rawResponse = await fetch(url);
          const content = await rawResponse.json();
          console.log("Event Description:", content);
          setHeadline(content.result.event.description);
        } catch (error) {
          console.error("Error fetching events:", error);
        }
      }

      getEventsByDate(date);
    }, [date]);

    // useEffect(() => {
    //     fetch('http://localhost:4000/api/concerts')
    //       .then(response => response.json())
    //       .then(data => {
    //         console.log(data); // Use setState here to update your component state
    //       })
    //       .catch(error => console.error('Error fetching data:', error));
    // }, []);
    

    
    useEffect(() => {
        class SPARQLQueryDispatcher {
            constructor( endpoint ) { this.endpoint = endpoint; }

            query( sparqlQuery ) {
                const fullUrl = this.endpoint + '?query=' + encodeURIComponent( sparqlQuery );
                const headers = { 'Accept': 'application/sparql-results+json' };
                return fetch( fullUrl, { headers } ).then( body => body.json() );
            }

        }

        const composer = `Johann Sebastian Bach`;
        const endpointUrl = 'https://query.wikidata.org/sparql';
        const sparqlQuery = `SELECT DISTINCT ?item ?itemLabel ?birthLocation  ?birthLocationLabel ?dateofbirth ?dateofdeath  ?genderLabel ?imageLabel WHERE {
            ?item (wdt:P31|wdt:P101|wdt:P106|wdt:P18)/wdt:P279* wd:Q482980 ;
                  rdfs:label "${composer}"@en ;
                  wdt:P19 ?birthLocation;
                  wdt:P569 ?dateofbirth;
                  wdt:P21 ?gender;
                  wdt:P570 ?dateofdeath;
                  OPTIONAL { ?item wdt:P18 ?image }
            SERVICE wikibase:label { bd:serviceParam wikibase:language "en". }
        }`;

        const queryDispatcher =
        new SPARQLQueryDispatcher( endpointUrl );

        async function
        fetchdata(){
            let response =queryDispatcher.query(sparqlQuery );
            return response;
        }

        async function
        main(){
            let response = await fetchdata();
            setCity(response.results.bindings[0].birthLocationLabel.value);
            setDoB(response.results.bindings[0].dateofbirth.value.split('T')[0]);
            setDoD(response.results.bindings[0].dateofdeath.value.split('T')[0]);
            setGender(response.results.bindings[0].genderLabel.value);
            setImage(response.results.bindings[0].imageLabel.value)
        }

        main();
    }, []);


  return (
    <>
    <Title style={{top: glassPosition.top, left: glassPosition.left}}> 10th Concert of the 1st Season </Title>

      <Overlay>
        <Container ref={glassRef}>
            <Image ref={imageRef} src={image} alt="Sample" />
            <Controls style={{
                width: imagePosSize.width, 
                height: '100px', 
                top: imagePosSize.top, 
                left: imagePosSize.left
            }}> {" "} </Controls>    

            <TextSection>
                <ReactFitty maxSize={30} wrapText={true} > <Header ref={headerRef}>Johann Sebastian Bach</Header> </ReactFitty>

                <InfoContainer>
                    <ReactFitty maxSize={20} minSize={10} wrapText> <InfoLabel > Date of Birth:  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {DoB}    </InfoLabel> </ReactFitty>
                    <ReactFitty maxSize={20} minSize={10} wrapText> <InfoLabel > Place of Birth: &nbsp;&nbsp;&nbsp;&nbsp; {city}   </InfoLabel> </ReactFitty>
                    <ReactFitty maxSize={20} minSize={10} wrapText> <InfoLabel > Gender:         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {gender} </InfoLabel> </ReactFitty>
                    <ReactFitty maxSize={20} minSize={10} wrapText> <InfoLabel > Date of Death:  &nbsp;&nbsp;&nbsp; {DoD}    </InfoLabel> </ReactFitty>
                </InfoContainer>


                <Headline style={{color: 'black', display: 'inline-block', paddingRight: '10px'}}> Today's Headline: </Headline>
                <Headline>{headline}</Headline>

                <ReactFitty maxSize={15} minSize={10} wrapText> <Header style={{marginTop: '30px'}}> Today's events: </Header> </ReactFitty>
                <InfoContainer>
                        <ReactFitty maxSize={20} minSize={3} wrapText> <InfoLabel > Work:     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 29 Jan - 1 Feb  </InfoLabel> </ReactFitty>
                        <ReactFitty maxSize={20} minSize={3} wrapText> <InfoLabel > Spans:    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 29 Jan - 1 Feb  </InfoLabel> </ReactFitty>
                        <ReactFitty maxSize={20} minSize={3} wrapText> <InfoLabel > Venue:    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Hallen   </InfoLabel> </ReactFitty>
                        <ReactFitty maxSize={20} minSize={3} wrapText> <InfoLabel > Time:     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 15:00   </InfoLabel> </ReactFitty>
                        <ReactFitty maxSize={20} minSize={3} wrapText> <InfoLabel > Orchestra:&nbsp;&nbsp;&nbsp;&nbsp; Name </InfoLabel> </ReactFitty>
                </InfoContainer>

            </TextSection>

        </Container>

      </Overlay>

      <Slider/>

    </>
  );
}

export default Info;
