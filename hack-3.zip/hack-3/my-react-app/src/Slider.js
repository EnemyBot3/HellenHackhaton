import React, { useState, useRef } from "react";
import ReactSlider from "react-slider";
import styled from 'styled-components';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faForward, faBackward } from '@fortawesome/free-solid-svg-icons';

const StyledDate = styled.h1`
    position: absolute;
    top: 25px;
    left: 50%;
    transform: translateX(-50%);
    font-size: 50px;
    color: white;
    margin: 0px;
    padding: 0px;
    white-space: nowrap;

    @media (max-width: 850px) {
        top: 15px;
        font-size: 45px;
    }
`;

const StyledSkipRight = styled(FontAwesomeIcon)`
    position: absolute;
    color: white;
    font-size: 40px;
    top: 30px;
    left: 80%;
    cursor: pointer;
    transform: translateX(-50%);
`;

const StyledSkipLeft = styled(FontAwesomeIcon)`
    position: absolute;
    color: white;
    font-size: 40px;
    top: 30px;
    left: 20%;
    cursor: pointer;
    transform: translateX(-50%);
`;

const StyledInput = styled.input`
    position: absolute;
    top: 25px;
    left: 50%;
    font-size: 50px;
    transform: translateX(-50%);
    opacity: 0;
    cursor: pointer;

    @media (max-width: 850px) {
        top: 15px;
        font-size: 45px;
    }
`;

function Slider() {
    const [sliderValue, setSliderValue] = useState(5000);
    const inputRef = useRef(null);

    const startDate = new Date(1858, 0, 30);
    const endDate = new Date(1912, 0, 11);
    const diffTime = Math.abs(endDate - startDate);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    const currentDate = new Date(startDate);
    currentDate.setDate(startDate.getDate() + sliderValue);

    const dateValue = isNaN(currentDate.getTime()) ? '' : currentDate.toISOString().slice(0, 10);
    const formattedDate = dateValue ? `${currentDate.getDate()} ${currentDate.toLocaleString('default', { month: 'short' })} ${currentDate.getFullYear()}` : 'Invalid Date';

    // Handle direct date input changes
    const handleDateInputChange = (event) => {
        const inputDate = new Date(event.target.value);
        const newSliderValue = Math.round((inputDate - startDate) / (1000 * 60 * 60 * 24));
        setSliderValue(newSliderValue);
    };

    // Handlers for skipping days
    const handleSkipBackward = () => {
        if (sliderValue > 0) {
            setSliderValue(sliderValue - 1);
        }
    };

    const handleSkipForward = () => {
        if (sliderValue < diffDays) {
            setSliderValue(sliderValue + 1);
        }
    };

    return (
        <>
            <StyledSkipLeft icon={faBackward} onClick={handleSkipBackward} />
            <StyledDate onClick={() => {inputRef.current?.focus();}}>{formattedDate}</StyledDate>
            <StyledSkipRight icon={faForward} onClick={handleSkipForward} />
            
            <StyledInput 
                ref={inputRef}
                type="date" 
                onChange={handleDateInputChange} 
                value={dateValue}
            />
            
            <ReactSlider
                className="customSlider"
                trackClassName="customSlider-track"
                markClassName="customSlider-mark"
                marks={3650/2}
                min={0}
                max={diffDays}
                defaultValue={30}
                value={sliderValue}
                step={.5}
                disabled
                onChange={(value) => setSliderValue(value)}
            />
        </>
    );
}

export default Slider;
