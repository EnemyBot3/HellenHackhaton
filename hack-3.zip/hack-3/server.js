const express = require('express');
const mysql = require('mysql');
const sqlite3 = require('sqlite3').verbose();

const cors = require('cors');
const app = express();
// app.use(cors());

// const connection = mysql.createConnection({
//     host: "halle-history.cluster-ctiiwouaw2qm.eu-west-2.rds.amazonaws.com",
//     user: "admin",
//     password: 'halle-pass',
//     database: 'halle',
// });

let db = new sqlite3.Database('./halle.sql.db', (err) => {
    if (err) { console.error(err.message); }
    console.log('Connected to the SQlite database.');
});
  
app.use(express.json());


// connection.connect(err => {
//   if (err) throw err;
//   console.log('Connected to the database!');
// });

app.get('/api/seasons', (req, res) => {
    connection.query('SELECT * FROM halle_seasons', (err, results) => {
        if (err) throw err;
        res.json(results);
    });
});

// app.get('/api/concerts', (req, res) => {
//     connection.query('SELECT * FROM halle_concerts', (err, results) => {
//         if (err) throw err;
//         res.json(results);
//     });
// });

app.get('/api/concerts', (req, res) => {
    db.all('SELECT * FROM halle_concerts', (err, results) => {
        if (err) {
            console.error(err.message);
            res.status(500).send(err.message);
            return;
        }
        res.json(results);
    });
});

app.get('/api/performances', (req, res) => {
    connection.query('SELECT * FROM halle_performances', (err, results) => {
        if (err) throw err;
        res.json(results);
    });
});

app.get('/api/works', (req, res) => {
    connection.query('SELECT * FROM halle_works', (err, results) => {
        if (err) throw err;
        res.json(results);
    });
});

app.get('/api/concert_performers', (req, res) => {
    connection.query('SELECT * FROM halle_concert_performers', (err, results) => {
        if (err) throw err;
        res.json(results);
    });
});

app.get('/api/performance_performers', (req, res) => {
    connection.query('SELECT * FROM halle_performance_performers', (err, results) => {
        if (err) throw err;
        res.json(results);
    });
});

app.get('/api/composers', (req, res) => {
    connection.query('SELECT * FROM halle_composers', (err, results) => {
        if (err) throw err;
        res.json(results);
    });
});

app.get('/api/venues', (req, res) => {
    connection.query('SELECT * FROM halle_venues', (err, results) => {
        if (err) throw err;
        res.json(results);
    });
});

app.listen(4000, () => {
  console.log('Server running on port 4000');
});
