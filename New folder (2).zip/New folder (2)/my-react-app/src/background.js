import React, { useEffect, useState } from 'react';
import styled, { keyframes, css } from 'styled-components';

const backgroundImage = 'https://i.imgur.com/xQdYC7x.jpg';

const Container = styled.div`
  position: relative;
  width: 100vw;
  height: 100vh;
  overflow: hidden;
`;

const Window = styled.div`
  position: absolute;
  width: 100vw;
  height: 100vh;
  background: url(${backgroundImage});
  background-size: cover;
  background-position: 50%;
  filter: blur(10px);
`;

const appearAndFall = keyframes`
  0% {
    opacity: 0;
    transform: translateY(-20px);
  }
  10% {
    opacity: 1;
    transform: translateY(0);
  }
  100% {
    transform: translateY(500px);
  }
`;

const Raindrop = styled.div`
  position: absolute;
  border-radius: 100%;
  background-image: url(${backgroundImage});
  background-size: calc(100vw * 0.05) calc(100vh * 0.05);
  background-position: center;
  transform: rotate(180deg);
  animation: ${props => css`${props.delay}s ${appearAndFall} linear infinite`};
`;

const Border = styled(Raindrop)`
  box-shadow: 0 0 0 2px rgba(0,0,0,0.5);
  margin-left: 2px;
  margin-top: 1px;
`;

function generateRaindrops() {
  const raindrops = [];
  for (let i = 0; i < 100; i++) {
    const size = 5 + Math.random() * 11;
    const stretch = 0.7 + Math.random() * 0.5;
    const delay = (Math.random() * 10) + 3;
    const x = Math.random() * 100;
    const y = Math.random() * 100;

    raindrops.push({
      x, y, width: size, height: size * stretch, delay
    });
  }
  return raindrops;
}

function Background() {
  const [raindrops, setRaindrops] = useState([]);

  useEffect(() => {
    setRaindrops(generateRaindrops());
  }, []);

  return (
    <Container>
      <Window />
      {raindrops.map((drop, index) => (
        <>
          <Border
            key={'border-' + index}
            style={{
              left: `${drop.x}vw`,
              top: `${drop.y}vh`,
              width: `${drop.width}px`,
              height: `${drop.height}px`
            }}
            delay={drop.delay}
          />
          <Raindrop
            key={'drop-' + index}
            style={{
              left: `${drop.x}vw`,
              top: `${drop.y}vh`,
              width: `${drop.width}px`,
              height: `${drop.height}px`
            }}
            delay={drop.delay}
          />
        </>
      ))}
    </Container>
  );
}

export default Background;