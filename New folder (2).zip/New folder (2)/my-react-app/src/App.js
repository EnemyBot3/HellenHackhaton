//     fetch('http://localhost:4000/api/composers')
//     .then(response => response.json())
//     .then(data => {
//       setData(data);  // Assuming data is an array of objects
//       console.log(data[0]);
//     })
//     .catch(error => console.error('Error fetching data:', error));
//   }, []);

//   //       {data ? (
//   //         <div>
//   //           <h2>Data Received:</h2>
//   //           <ul>
//   //             {data.map((item, index) => (
//   //               <li key={index}>{JSON.stringify(item)}</li>
//   //             ))}
//   //           </ul>
//   //         </div>
//   //       ) : (
//   //         <p>No data received yet.</p>
//   //       )}


import React, { useEffect, useState } from 'react';
import styled, { keyframes, css } from 'styled-components';

import Background from './background';

function App() {

  return (
    <Background />
  );
}

export default App;